# SPA (Simple Plugin API)

* SPA [Design](design.md)
* [Data format](pod.md)
