# pipewire-pulseaudio
PulseAudio client library for PipeWire

This is a replacement libpulse.so library. Clients using this library will
transparently connect to PipeWire.
